from PIL import Image
from blind_watermark import WaterMark
import numpy as np
import time, sys

from numpy.lib.function_base import extract
import os

def main(arg1):
    img_orgnl = arg1
    watermark_logo = "C:/Users/2h1/Desktop/server/public/watermark.png"
    
    embed_img = blind_watermark(img_orgnl,watermark_logo)
    #embed_img=input("embedded: ")
    #extract_mrk = extract_watermark(embed_img)

    

def blind_watermark(img_orgnl,scram_img):
    outputPath='C:/Users/2h1/Desktop/server/public/2embedded.png'
    bwm1 = WaterMark(password_wm=1, password_img=1)
    # read original image
    bwm1.read_img(img_orgnl)
    # read watermark
    bwm1.read_wm(scram_img)
    #embed
    bwm1.embed(outputPath)
    return outputPath

def extract_watermark(embed_img):
    bwm1 = WaterMark(password_wm=1, password_img=1)
    # notice that wm_shape is necessary

    bwm1.extract(filename=embed_img, wm_shape=(30, 50), out_wm_name='3extracted.png', )
    extract_mrk = os.path.basename('C:/Users/2h1/Desktop/server/public/3extracted.png')
    return extract_mrk


if __name__ == '__main__':
    main(sys.argv[1])
